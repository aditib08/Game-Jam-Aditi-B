let catcher; 
let fallingObject;
let enterButton;
let screen = 0;
let score = 0;
let goalScore = 5;
let level = 1;

function setup() {
  createCanvas(600, 400);
  background(149,209,153);

  //create sprites
  catcher = new Sprite(200,380,100,20,'k');
  catcher.color = color(30,30,30);
  fallingObjectG = new Sprite(100,0,10);
  fallingObjectG.color = color(143,233,104);
  fallingObjectY = new Sprite(100,0,10);
  fallingObjectY.color = color(243,219,97);
  fallingObjectR = new Sprite(100,0,10);
  fallingObjectR.color = color(223,73,73);

  textSize(30);
  text("Play THE RECYCLER and save a \ncity from being overrun with trash", 60, 150); 
  enterButton = new Sprite(width/2 - 130 , height/2+100);
  enterButton.w = 100;
  enterButton.h = 50;
  enterButton.collider = "k";
  enterButton.text = "Play";
  enterButton.color = "lightblue";

  instructionButton = new Sprite(width/2 + 80, height/2+100);
  instructionButton.w = 180;
  instructionButton.h = 50;
  instructionButton.collider = "k";
  instructionButton.text = "Instructions";
  instructionButton.color = "lightblue";

  playAgainButton = new Sprite(-100, height/2+100);
  playAgainButton.w = 170;
  playAgainButton.h = 50;
  playAgainButton.collider = "k";
  playAgainButton.text = "Level Up!";
  playAgainButton.color = 'lightblue';

  homeButton = new Sprite(-110, height/2+100);
  homeButton.w = 170;
  homeButton.h = 50;
  homeButton.collider = "k";
  homeButton.text = "Home";
  homeButton.color = 'lightblue';


  //set catcher and fallingObject to be off the screen until screen 1 is shown
  catcher.x = -100;
  fallingObjectG.y = -50;
  fallingObjectY.y = -60;
  fallingObjectR.y = -70;

}


//draw
function draw() {

  //this if statement will only run once, when you first press the enter button so everything inside will only occur once. 
  if (enterButton.mouse.presses()){
    catcher.x = width/2;
    screen = 1;
    //set fallingObject to starting velocity
    fallingObjectG.vel.y = 3;
    fallingObjectY.vel.y = 3;
    fallingObjectR.vel.y = 3;

    fallingObjectG.x = 100;
    fallingObjectY.x = 200;
    fallingObjectR.x = 300;

  }

  if(instructionButton.mouse.presses()){
    screen = 2
  }

  if(playAgainButton.mouse.presses()){
    screen = 1;
    goalScore = goalScore + 5;
    level++;
    score = 0;
  }

  if(homeButton.mouse.presses()){
    homeButton.x = -100
    screen = 0;
    background(149,209,153);
    textSize(30);
    text("Play THE RECYCLER and save a \ncity from being overrun with trash", 60, 150); 

    enterButton.x = width/2 - 130;
    enterButton.y = height/2+100;
    playAgainButton.x = -100;
    instructionButton.x = width/2 + 80;
    instructionButton.y = height/2+100;
    fallingObjectG.x = -500;
    fallingObjectY.x = -500;
    fallingObjectR.x = -500;

    score = 0;
  }

  if (screen == 1){
    showScreen1();
  }

  if(screen == 2){
    showScreen2(); 
  }
  
}



//functions 
function showScreen1(){
  
  screen = 1; 
  background("paleturquoise");

  //remove extra buttons from screen
  enterButton.x = -100;
  instructionButton.x = -110
  playAgainButton.x = -110
  homeButton.x = -120


  //fallingObject movement
  if (fallingObjectG.y >= height){
    fallingObjectG.y = 0;
    fallingObjectG.x = random(0,width);
    fallingObjectG.vel.y = random(2,5);
  }
  
  if (fallingObjectY.y >= height){
    fallingObjectY.y = 0;
    fallingObjectY.x = random(0,width);
    fallingObjectY.vel.y = random(2,5);    
  }

    if (fallingObjectR.y >= height){
    fallingObjectR.y = 0;
    fallingObjectR.x = random(0,width);
    fallingObjectR.vel.y = random(2,5);    
  }
  
  // //catcher movement 
  if (kb.pressing("right")){
    catcher.vel.x = 3; 
  } else if (kb.pressing("left")){
    catcher.vel.x = -3; 
  } else {
    catcher.vel.x = 0;
  }
  
  //Keeping the catcher on the screen 
  if (catcher.x < 0 + catcher.width / 2){
      catcher.x = catcher.width / 2; 
  } 
  if (catcher.x > width - catcher.width / 2){
      catcher.x = width - catcher.width / 2;
  }

  //when catcher collides with falling object
    if (fallingObjectG.collides(catcher)) {
    fallingObjectG.y = 0;
    fallingObjectG.x = random(width);
    fallingObjectG.vel.y = random(1,5);
    fallingObjectG.direction = "down";
    score++;
  }

      if (fallingObjectY.collides(catcher)) {
    fallingObjectY.y = 0;
    fallingObjectY.x = random(width);
    fallingObjectY.vel.y = random(1,5);
    fallingObjectY.direction = "down";
    score--;
  }

      if (fallingObjectR.collides(catcher)) {
    fallingObjectR.y = 0;
    fallingObjectR.x = random(width);
    fallingObjectR.vel.y = random(1,5);
    fallingObjectR.direction = "down";
    score = score - 3;
  }

  fill(0, 128, 128);
  textSize(20);
  text("Score = " + score, 10, 30);
  text("Goal Score = " + goalScore, 10, 50);
  text("Level = " + level, 10, 70)

  if(score >= goalScore){
  background("paleturquoise");
  catcher.x = -100;
  fallingObjectG.y = -50;
  fallingObjectY.y = -50;
  fallingObjectR.y = -50;

  text("You Win!", 250, 200);

  playAgainButton.x = width/2 - 120;
  homeButton.x = width/2 + 120;
  homeButton.y = height/2+100;
  }
  
}

function showScreen2() {
screen = 2;

instructionButton.x = -110;
enterButton.y = height/2+130;
homeButton.x = width/2 + 80;
homeButton.y = height/2+130;

textSize(30);
background(149,209,153);
text("Instructions", 200, 50);
textSize(15);
text("Use your left and right arrow keys to move the catcher at the bottom\nof the screen to collect objects as they fall", 10, 90);
text("The green items are worth +1(papers, cardboards, plastics), the yellow items are \n-1(metals and glasses), and the red items are -3(food waste)", 10, 130);
text("For more resources on saving the environment:  \nhttps://www.environmentalmanagementsystem.com.au/environmental-basics.html \nhttps://oceanservice.noaa.gov/ocean/earthday.html\nhttps://www.wwf.org.uk/thingsyoucando\nhttps://www.inspirecleanenergy.com/blog/sustainable-living/ways-to-protect-the-\nenvironment", 10, 180); 
}